package com.example.ex00;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex00Application {

	public static void main(String[] args) {
		SpringApplication.run(Ex00Application.class, args);
	}

}
